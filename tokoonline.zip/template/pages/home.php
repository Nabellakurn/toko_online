<!DOCTYPE html>
<html>
<title>Home</title>

<?php
    include "header.php";
?>
<h2>Selamat datang <?=$_SESSION['nama_pelanggan']?> di website Toko MAINKUY.</h2>

<?php
    include "footer.php";
?>